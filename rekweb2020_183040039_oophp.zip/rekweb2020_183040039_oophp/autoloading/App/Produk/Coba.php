<?php 

class Coba {
	public function __construct() {
		echo "Ini adalah kelas Coba";
	}
}

 ?>